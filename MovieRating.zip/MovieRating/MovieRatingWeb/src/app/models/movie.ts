export class Movie{
    movieID:number;
    movieName:string;
    releaseDate:Date;
    description:string;
    averageRating:number;
}