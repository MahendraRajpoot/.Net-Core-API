export class MovieRating{
    movieRatingID: number;
    movieID:number;
    rating:number;
    comment:string; 
    createdBy:number;
}